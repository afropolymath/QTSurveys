<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Brands extends MY_Controller {

	public function index() {
		
	}
	public function create() {
		if($this->input->post('submit')) {
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'required|xss_clean');
			$this->form_validation->set_rules('position', 'Position', 'required|xss_clean');
			if($this->form_validation->run()) {
				$vars = $this->input->post();
				if(!preg_match("/^(\d)+,(\d)+$/", $vars['position'])) {

				}
				unset($vars['submit']);
			    $config['upload_path'] = './uploads/brands/';
			    $config['allowed_types'] = 'gif|jpg|png';
			    $config['max_size'] = '2048';
			    $config['max_width']  = '2000';
			    $config['max_height']  = '2000';
			    $config['min_width']  = '0';
			    $config['min_height']  = '0';
			    $config['overwrite'] = TRUE;
			    $config['encrypt_name'] = FALSE;
			    $config['remove_spaces'] = TRUE;
		    	$image_file_name = $_FILES['logo']['name'];
				if($image_file_name != "") {
					$path = pathinfo($image_file_name);
					$config['file_name'] = substr(sha1($image_file_name), 0, 16) .".".$path['extension'];
					
					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('logo')) {
						$error = true;
						foreach($this->upload->display_errors() as $message) {
							$this->message->set('error', $message);
						}
					} else { 
						$vars['logo'] = "uploads/brands/" . $config['file_name'];
						$this->brand->insert($vars);
						$this->message->set('success',"Created brand successfully");
						redirect("site/home");
					}
				} else {
					$this->message->set('error', 'You must provide the location of the logo');
				}
			}	
		}
	}

}

/* End of file brands.php */
/* Location: ./application/controllers/brands.php */
?>