<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function index() {
		//Select Brand
	}
	public function edit() {

	}
	public function resize($brand_id = null, $template_id = null) {
		if(!isset($brand_id) && $this->session->userdata('working_brand')) {
			$brand_id = $this->session->userdata('working_brand');
		}
		if(isset($brand_id) && $this->data['brand'] = $this->brand->get($brand_id)) {
			$array = array( 'working_brand' => $this->data['brand']->id );
			$this->session->set_userdata( $array );
			$this->output->enable_profiler(TRUE);
			$this->data['image_library'] = $this->image->get_all();
		} else {
			redirect("site/home");
		}
	}
	public function image_upload() {
		if($this->input->post('submit')) {
			$vars = $this->input->post();
			unset($vars['submit']);
		    $config['upload_path'] = './uploads/';
		    $config['allowed_types'] = 'gif|jpg|png';
		    $config['max_size'] = '2048';
		    $config['max_width']  = '2000';
		    $config['max_height']  = '2000';
		    $config['min_width']  = '403';
		    $config['min_height']  = '403';
		    $config['overwrite'] = TRUE;
		    $config['encrypt_name'] = FALSE;
		    $config['remove_spaces'] = TRUE;
		    $image_file_name = $_FILES['image_file']['name'];
			if($image_file_name != "") {
				$path = pathinfo($image_file_name);
				$config['file_name'] = substr(sha1($image_file_name), 0, 16) .".".$path['extension'];

				$this->load->library('upload', $config);

				if ( ! $this->upload->do_upload('image_file')) {
					$error = true;
					foreach($this->upload->display_errors() as $message) {
						$this->message->set('error', $message);
					}
				} else {
					$vars['image_file'] = "uploads/" . $config['file_name'];
					$this->image->insert($vars);
					$this->message->set('success',"Successfully uploaded the image to the library");
				}
			} else {
				$this->message->set('error', 'You must provide the location of the scanned passport bio-data page');
			}
		}
		redirect("site/resize");
	}
	public function crop_image() {
		if($this->input->post()) {
			$config['image_library'] = 'gd2';
			$config['source_image']	= str_replace(site_url(), "./", $this->input->post("image_location"));
			$props = getimagesize($config['source_image']);
			$originalW = $props[0];
			$originalH = $props[1];
			$returnedW = $this->input->post("ow");
			$returnedH = $this->input->post("oh");
			
			$hf = $originalW / $returnedW;
			$vf = $originalH / $returnedH;
			$rX = floor($this->input->post("x1") * $hf);
			$rY = floor($this->input->post("y1") * $vf);
			$rW	 = $this->input->post("w") * $hf;
			$rH	= $this->input->post("h") * $vf;

			$targ_w = $targ_h = 403;
			$jpeg_quality = 90;

			$src = $config['source_image'];
			$ext = pathinfo($config['source_image'])['extension'];
			$img_r = null;
			switch($ext) {
				case 'jpg':
				case 'jpeg':
					$img_r = imagecreatefromjpeg($src);
					break;
				case 'png':
					$img_r = imagecreatefrompng($src);
					break;
				case 'gif':
					$img_r = imagecreatefromgif($src);
					break;
				case 'default':
					break;
			}

			$dst_r = ImageCreateTrueColor( $targ_w, $targ_h );

			imagecopyresampled($dst_r, $img_r, 0, 0, $rX, $rY, $targ_w, $targ_h, $rW, $rH);
			$output_filename = "./uploads/posts/".substr(sha1(time()), 0, 20).".$ext";
			switch($ext) {
				case 'jpg':
				case 'jpeg':
					imagejpeg($dst_r, $output_filename, $jpeg_quality);
					break;
				case 'png':
					imagepng($dst_r, $output_filename, $jpeg_quality/10);
					break;
				case 'gif':
					imagegif($dst_r, $output_filename);
					break;
				case 'default':
					break;
			}
			if(! $this->_watermark_image($output_filename)) {
				$this->message->set('error', 'There was a problem while branding your image');
			} else {
				$this->message->set('success', 'Successfully branded your image.<br/>Click '.anchor($output_filename,'here').' to download');
			}
		}
		redirect('site/resize');
	}
	private function _watermark_image($imagefile) {
		$working_brand = $this->brand->get($this->session->userdata('working_brand'));
		$config['image_library'] = 'imagemagick';
		$config['wm_type'] = 'overlay';
		$config['wm_opacity'] = 100;
		$config['wm_hor_alignment'] = 'left';
		$config['wm_vrt_alignment'] = 'top';
		$coords = explode(",", $working_brand->position);
		$config['wm_hor_offset'] = $coords[0];
		$config['wm_vrt_offset'] = $coords[1];
		$config['source_image'] = $imagefile;
		$config['new_image'] = $imagefile;
		$config['wm_overlay_path'] = './'.$working_brand->logo;
		$config['dynamic_output'] = FALSE;
		$this->image_lib->initialize($config); 
		echo $new_image;
		if( $this->image_lib->watermark() ) {
			return true;
		} else {
			return false;
		}
	}
	public function home() {
		$this->data['brands'] = $this->brand->get_all();
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */