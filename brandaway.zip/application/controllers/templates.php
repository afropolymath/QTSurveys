<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templates extends MY_Controller {

	public function index() {
		
	}
	public function display($id) {
		if(isset($id)) {
			$this->data['current_brand'] = $this->brand->get($id);
		}
	}

}

/* End of file templates.php */
/* Location: ./application/controllers/templates.php */
?>