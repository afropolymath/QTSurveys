<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Image_model extends MY_Model {

	

}

/* End of file image_model.php */
/* Location: ./application/models/image_model.php */
?>