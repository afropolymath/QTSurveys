<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Brand_model extends MY_Model {

	

}

/* End of file brand_model.php */
/* Location: ./application/models/brand_model.php */
?>