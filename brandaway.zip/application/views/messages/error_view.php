<?php foreach ($messages as $message): ?>
	<div class="alert-box alert radius"><?= $message ?></div>
<?php endforeach ?>
