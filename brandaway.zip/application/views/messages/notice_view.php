	<div class="alert alert-info">
		<ul>
		<?php foreach ($messages as $message): ?>
			<li><?php echo $message ?></li>
		<?php endforeach ?>
		</ul>
	</div>
