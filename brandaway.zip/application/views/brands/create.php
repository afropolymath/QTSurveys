<div class="row">
	<div class="large-12 columns">
		<?= validation_errors('<div class="alert-box alert radius">', '</div>'); ?>
		<?= $this->message->display('success'); ?>
		<?= $this->message->display('error'); ?>
       	<h4 class="application-title">Create Brand</h4>
		<?= form_open_multipart('brands/create');?>
		<div id="ajax-error-message"></div>
		<label for="brand_name">Brand Name</label>
		<input type="text" name="brand_name" id="brand_name"/>
		<label for="position">Position</label>
		<input type="text" name="position" id="position"/>
		<label for="logo">Select the image</label>
		<input type="file" name="logo" id="logo"/>
		<?= form_submit('submit', 'Create Brand','class = "small button"'); ?>
		<?= form_close(); ?>
	</div>
</div>