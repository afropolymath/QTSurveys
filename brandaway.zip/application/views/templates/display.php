<div>
	<ul class="breadcrumbs">
	  	<li class="current"><a href="#">Templates for <?= $current_brand->brand_name; ?></a></li>
	</ul>
	<ul class="large-block-grid-5" id="brand-list">
      <li><?= anchor("site/resize/".$current_brand->id."/1", "Default Template"); ?></li>
      <li><a>Create a Template</a></li>
    </ul>
</div>