<div class="row">
  <div class="large-12 columns">
    <form>
      <div class="row">
        <div class="large-6 large-centered columns">
          <label>Username</label>
          <input type="text" placeholder="Username" class="panel radius"/>
        </div>
      </div>
      <div class="row">
        <div class="large-6 large-centered columns">
          <label>Password</label>
          <input type="text" placeholder="Password" class="panel radius"/>
        </div>
      </div>
      <div class="row">
        <div class="large-6 large-centered columns">
          <input type="submit" value="Enter" class="button radius" id="loginButton"/>
        </div>
      </div>
    </form>
  </div>
</div>