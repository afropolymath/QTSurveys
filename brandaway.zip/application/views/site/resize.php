<!-- Create Image Modal Box -->
<div id="myModal" class="tiny reveal-modal" data-reveal>
	<h2>Image Upload</h2>
	<p class="lead">Select the image you wish to upload.</p>
	<?= form_open_multipart('site/image_upload');?>
	<label for="category">Select Category</label>
	<? $options = array("Food","People"); ?>
	<?= form_dropdown('category', $options, 'default'); ?>
	<label for="image_file">Select the image</label>
	<input type="file" name="image_file"/>
	<a class="close-reveal-modal">&#215;</a>
	<?= form_submit('submit', 'Upload','class = "small button"'); ?>
	<?= form_close(); ?>
</div>
<div class="row">
	<div class="large-8 columns">
		<ul class="breadcrumbs">
			<li><?= anchor("site/home","Home"); ?></li>
		  	<li class="current"><a href="#"><?= $brand->brand_name; ?></a></li>
		</ul>
		<div class="inset">
			<div class="brand-icon"><?= img($brand->logo); ?></div>
			<h4 class="application-title">Branding for <?= $brand->brand_name; ?></h4>
			<p class="sub-title">TEMPLATE NAME: INVERSE</p>
		</div>
		<div>
			<?= validation_errors('<div class="alert-box alert radius">', '</div>'); ?>
			<?= $this->message->display('success'); ?>
			<?= $this->message->display('error'); ?>
		</div>
		<div id="application-window">
			<div class="distress">Select an image to begin</div>
		</div>
		<?= form_open('site/crop_image', array("class"=>"image_crop_form")); ?>
		<div class="coordinates">
			<input type="text" name="image_location" id="image_location"/>
			<div class="row">
				<div class="small-2 columns"><input type="text" id="x1" name="x1"></div>
				<div class="small-2 columns"><input type="text" id="y1" name="y1"></div>
				<div class="small-2 columns"><input type="text" id="x2" name="x2"></div>
				<div class="small-2 columns"><input type="text" id="y2" name="y2"></div>
				<div class="small-2 columns"><input type="text" id="w" name="w"></div>
				<div class="small-2 columns"><input type="text" id="h" name="h"></div>
			</div>
			<div class="row">
				<div class="small-6 columns"><input type="text" id="ow" name="ow"></div>
				<div class="small-6 columns"><input type="text" id="oh" name="oh"></div>
			</div>
		</div>
		<div class="row">
			<div class="small-12 columns">
				<input type="submit" name="crop" value="Crop Image" id="crop" class="small button" disabled/>
			</div>
		</div>
		<!--div style="width:403px;height:403px;overflow:hidden;">
			<img src="<?= site_url('uploads/19875e437922e17b.jpg'); ?>" id="preview"/>
		</div-->
		<?= form_close(); ?>
	</div>
	<div class="large-4 columns">
		<div class="control-icons">
			<?= anchor('#', 'List', array("class" => "small button list-icon")); ?>
			<?= anchor('#', 'Grid', array("class" => "small button grid-icon")); ?>
			<?= anchor('site/image_upload', 'Add Image', array("class" => "small button add-icon","data-reveal-id"=>"myModal", "data-reveal" => FALSE)); ?>
		</div>
		<div class="image-library">
			<ul>
			<? foreach($image_library as $image): ?>
				<li><a href="<?= site_url($image->image_file); ?>" class="img-dynamic-load"><?= $image->image_file; ?></a></li>
			<? endforeach; ?>
			</ul>
		</div>
	</div>
</div>