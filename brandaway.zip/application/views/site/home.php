<!-- Create Image Modal Box -->
<div id="generic-modal" class="tiny reveal-modal" data-reveal>

</div>
<div id="slidercontent">
    	
</div>    
<div class="row" id="maincontent">
	<div class="large-12 large-centered columns">
		<?= validation_errors('<div class="alert-box alert radius">', '</div>'); ?>
		<?= $this->message->display('success'); ?>
		<?= $this->message->display('error'); ?>
		<div class="brands-container">	
			<h4 class="application-title">Select Brand</h4>
            <div>
            	<? if(isset($brands)): ?>
            	<ul class="small-block-grid-5" id="brand-list">
            		<? foreach($brands as $brand): ?>
                	<li>
                		<?= anchor("templates/display/" . $brand->id, img($brand->logo), array("class" => "list-templates")); ?>
                		<p><?= $brand->brand_name; ?></p>
                		<p class="sub-text">0 TEMPLATES</p>
                	</li>
                	<? endforeach; ?>
                	<li><?= anchor("brands/create", "Create Brand"); ?></li>
                </ul>
            	<? endif; ?>
            </div>
       </div>
       <div class="templates-container">
       		<h4 class="application-title">Select Templates</h4>
           	<div>
				<div class="distress">Select a brand to begin</div>
           	</div>
       </div>
   </div>
</div>