<!doctype html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Welcome to BrandAway</title>
		<link rel="stylesheet" href="<?= $normalize_css; ?>" />
		<link rel="stylesheet" href="<?= $foundation_css; ?>" />
		<link rel="stylesheet" href="<?= $jcrop_css; ?>" type="text/css" />
    	<link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="<?= $app_css; ?>" />
		<script src="<?= $modernizr_js; ?>"></script>
	</head>
	<body>
		<div id="header">
	    	<div class="row">
	          <div class="large-2 large-offset-10 columns">
	            <a class="button signout">Sign Out</a>
	          </div>
	        </div>
		</div>
		<div id="content">
			<div class="row">
				<div class="large-4 large-centered columns">
			    	<?= img(array("src" => "assets/img/logo.png", "id" => "logo")); ?>
				</div>
			</div>
	    	<?= $yield; ?>
	    </div>
		<div id="footer">
			<div class="row">
	        	<div class="large-6 columns">
	            	2014 Brandaway
	            </div>
	        </div>
		</div>
	    <script src="<?= $jquery; ?>"></script>
	    <script src="<?= $foundation_js; ?>"></script>
		<script src="<?= $jcrop_js; ?>"></script>
	    <script type="text/javascript">
	    	$(document).foundation();
	    	$(function() {
	    		/* CROP FUNCTIONALITY */
	    		function buildJCrop() {
	    			$("#crop").removeAttr("disabled");
	    			$('#cropbox').Jcrop({
	    				onSelect: showCoords,
            			onChange: showCoords,
            			setSelect: [ 0, 0, 403, 403 ],
            			minSize: [403,403],
            			aspectRatio: 1
	    			}, function() {
		            	$("#ow").val($(".jcrop-holder").width());
		            	$("#oh").val($(".jcrop-holder").height());
	    			});
	    		}
	    		function imageLocation(location) {
	    			$("#image_location").val(location);
	    		}
				function showCoords(c) {
					$('#x1').val(c.x);
					$('#y1').val(c.y);
					$('#x2').val(c.x2);
					$('#y2').val(c.y2);
					$('#w').val(c.w);
					$('#h').val(c.h);
				};
	    		$(document).on("click",".img-dynamic-load", function() {
	    			var $link = $(this).attr("href")
	    			var $loc = $("#image_location").val();
	    			var htmlImg = '<img src="' + $link + '" id="cropbox" />';
   					$('#application-window').html(htmlImg);
   					imageLocation($link);
	    			buildJCrop();
	    			return false;
	    		});
	    		$(document).on("click","#crop", function() {
	    			$.post($(".image_crop_form").attr("action"), function(data) {

	    			})
	    		});
	    		$(document).on("click",".list-templates", function() {
	    			$(".templates-container div").load($(this).attr("href"));
	    			return false;
	    		})
	    		/*
	    		$(document).on("submit",".ajax-submit", function() {
	    			var filefield = $('#logo').val();
	    			var namefield = $("#brand_name").val();
	    			var positionfield = $("#position").val();
	    			if(namefield == "" || positionfield == "" || filefield == "") {
	    				$("#ajax-error-message").html("One or more of your fields were not initialized");
	    				return false;
	    			}
	    		})*/
	    	})
	    </script>
	</body>
</html>
